﻿#include <iostream>
#include "../Lab12/Header.h"

int main()
{
	double** n = nullptr;
	size_t rows, cols;
	readNew(n, rows, cols);
	printMatrix(n, rows, cols);
	std::cout << std::endl;
	//deleteRowAndColumn(n, rows, cols);
	//deleteRowByPredicate(zeroPredicate, n, rows, cols);
	//printMatrix(n, rows, cols);
	std::cout << diagonalRatioInMatrix(n, rows, cols) << std::endl;
	//n = insertColumn(n, rows, cols);
	//printMatrix(n, rows, cols);
	deleteMatrix(n, rows, cols);
	return 0;
}