#include <iostream>

void readNew(double**& m, size_t& rows, size_t& cols) {
	m = nullptr;
	std::cout << "Enter number of rows" << std::endl;
	std::cin >> rows;
	std::cout << "Enter number of columns" << std::endl;
	std::cin >> cols;
	m = new  double* [rows];
	for (int i = 0; i < rows; ++i) m[i] = new double[cols];
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			std::cout << "Enter m[" << i << "][" << j << "]" << std::endl;
			std::cin >> m[i][j];
		}
	}
}
bool zeroPredicate(double*& row, size_t& cols) {
	for (int i = 0; i < cols; ++i) {
		if (row[i] == 0) return false;
	}
	return true;
}

bool positivePredicate(double*& row, size_t & cols) {
	for (int i = 0; i < cols; ++i) {
		if (row[i] > 0) return false;
	}
	return true;
}
void printMatrix(double**& m, size_t& rows, size_t& cols) {
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			std::cout << m[i][j] << " ";
		}
		std::cout << std::endl;
	}
}
void deleteMatrix(double**& m, size_t rows, size_t cols) {
	for (int i = 0; i < rows; ++i) delete[] m[i];
	delete[] m;
	m = nullptr;
}
double diagonalRatioInMatrix(double**& m, const size_t rows, const size_t cols) {
	double main_diag = 0, secondary_diag = 0;
	for (int i = 0; i < rows; ++i) {
		main_diag += m[i][i];
		secondary_diag += m[i][rows - i - 1];
	}
	return main_diag / secondary_diag;
}
double** insertColumn(double**& m, size_t& rows, size_t& cols) {
	double** n = nullptr;
	n = new double* [rows];
	for (int i = 0; i < rows; ++i) n[i] = new double[cols + 1];
	double max;
	for (int i = 0; i < rows; ++i) {
		max = 0;
		for (int j = 0; j < cols; ++j) {
			if (m[i][j] >= max) max = m[i][j];
			n[i][j] = m[i][j];
		}
		n[i][cols] = max;
	}
	deleteMatrix(m, rows, cols);
	cols += 1;
	return n;
}
void deleteRowAndColumn(double**& m, size_t& rows, size_t& cols) {
	int row_max, col_max;
	double max = 0;
	// finding max element, and its i and j
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			if (m[i][j] >= max) {
				max = m[i][j];
				row_max = i;
				col_max = j;
			}
		}
	}
	// creating new result matrix
	double** new_matr = new double* [rows - 1];
	for (int i = 0; i < rows - 1; ++i) {
		new_matr[i] = new double[cols - 1];
	}
	// filling new result matrix with values
	int add_to_i = 0, add_to_j = 0;
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			if (i == row_max || j == col_max) {
				continue;
			}
			add_to_j = (i > row_max) ? -1 : 0;
			add_to_i = (j > col_max) ? -1 : 0;

			new_matr[i + add_to_i][j + add_to_j] = m[i][j];
		}
	}
	std::swap(new_matr, m);
	--cols; --rows;
	deleteMatrix(new_matr, rows, cols);
}
void deleteRowByPredicate(bool(*pred)(double*& m, size_t& cols),
	double**& m, size_t& rows, size_t& cols) {
	// counting the "good" rows
	int good_rows = 0;
	for (int i = 0; i < rows; ++i) {
		good_rows += pred(m[i], cols) * 1;
	}
	// creating new matrix with only good rows
	double** new_matr = new double* [good_rows];
	for (int i = 0; i < good_rows; ++i) new_matr[i] = new double[cols];
	int new_ind = 0;
	for (int i = 0; i < rows; ++i) {
		if (pred(m[i], cols)) {
			for (int j = 0; j < cols; ++j) {
				new_matr[new_ind][j] = m[i][j];
			}
			new_ind++;
		}
	}
	std::swap(new_matr, m);
	rows = good_rows;
	deleteMatrix(new_matr, rows, cols);

}
