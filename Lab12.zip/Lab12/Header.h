#pragma once

void readNew(double**& m, size_t& rows, size_t& cols);
void printMatrix(double**& m, size_t& rows, size_t& cols);
void deleteMatrix(double**& m, size_t rows, size_t cols);
double diagonalRatioInMatrix(double**& m, const size_t rows, const size_t cols);
double** insertColumn(double**& m, size_t& rows, size_t& cols);
void deleteRowAndColumn(double**& m, size_t& rows, size_t& cols);
bool zeroPredicate(double*& row, size_t& cols);
bool positivePredicate(double*& row, size_t& cols);
void deleteRowByPredicate(bool(*pred)(double*& m, size_t& cols),
	double**& m, size_t& rows, size_t& cols);