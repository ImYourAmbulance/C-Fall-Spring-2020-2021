// Lab16.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

double minNumberInFile(const string& filename) {
	ifstream f(filename);
	if (!f.is_open()) cout << "Cannot open the file " << filename << endl;
	double curr = 0, min;
	if (f >> curr) min = curr;
	else cout << "The file " << filename << " is empty" << endl;
	min = curr;
	while (f >> curr) {
		if (abs(curr) < abs(min)) min = abs(curr);
	}
	f.close();
	return min;
}

void minMaxinString(const string& s, double& min, double& max) {
	stringstream s1;
	s1 << s;
	double curr_numb;
	s1 >> curr_numb;
	max = min = curr_numb;
	while (s1 >> curr_numb) {
		if (curr_numb > max) max = curr_numb;
		if (curr_numb < min) min = curr_numb;
	}
}


void minMaxInEveryLine(const string& filename) {
	ifstream f(filename);
	ofstream res("result.txt");
	string s;
	double min, max;
	while (getline(f, s)) {
		minMaxinString(s, min, max);
		res << "min = " << min << " max = " << max << endl;
	}
	f.close();
}


int main()
{
	cout << minNumberInFile("task1.txt") << endl;
	
	minMaxInEveryLine("task1.txt");
	// file result.txt will be created 
	return 0;
}
