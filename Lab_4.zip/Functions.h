#pragma once
#include <iostream>

using namespace std;

void print_bin(int number);

void print_bin(short int number);

void print_bin(char number);

void print_mem_bin(int number);

void print_mem_bin(short int number);

void print_mem_bin(char number);

int CheckIBite(int n, int i);

void InvertBite(int& n, int i);

int Factorial(int n);

double CalculateExponentiation(double x, double eps);

double CalculateCos(double angle, double eps);

void ExpOnSegment(double a, double b, double pace);

void CosOnSegment(double a, double b, double pace);

void FunctionOnSegment(void(*func)(double a, double eps),
	double a, double b, double pace);
