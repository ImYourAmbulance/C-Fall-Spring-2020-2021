﻿#include <iostream>
#include "Functions.h"
using namespace std;

int main() {
	std::cout << "Comparing Cos from Cmath and my own CalculateCos" << '\n';
	std::cout << std::cos(0.8) << '\n';
	std::cout << "That's my function with precise is equal to 0.0000001" << '\n';
	std::cout << CalculateCos(0.8, 0.0000001) << '\n';
	std::cout << "Comparing Exp and my own CalculateExponentiation" << '\n';
	std::cout << std::exp(3.2) << '\n';
	std::cout << "That's my function with precise is equal to 0.0000001" << '\n';
	std::cout << CalculateExponentiation(3.2, 0.0000001) << '\n';
	std::cout << "Exp on segment" << '\n';
	ExpOnSegment(1, 10, 1);
	std::cout << "Cos on segment" << '\n';
	CosOnSegment(0, 1, 0.1);
	return 0;
}
