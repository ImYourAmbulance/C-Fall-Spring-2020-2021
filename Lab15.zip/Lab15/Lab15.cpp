#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cstring>
using namespace std;
int symbCount(const string& filename) {
	ifstream f(filename);
	char symbol;
	int latin_cnt = 0;
	while (f.get(symbol)) {
		if ((symbol <= 'z' && symbol >= 'a') || (symbol <= 'Z' && symbol >= 'A')) ++latin_cnt;
	}
	f.close();
	return latin_cnt;
}



string longestLine(const string& filename) {
	ifstream f(filename);
	string curr_string;
	string max_string;
	int max_length = 0;
	while (getline(f, curr_string)) {
		if (curr_string.size() > max_length) {
			max_length = curr_string.size();
			max_string = curr_string;
		}
	}
	f.close();
	return max_string;
}

int wordCount(const string& str) {
	string s = str;
	// checking 
	if (str == "") return 0;
	// deleting spaces at the begining
	while (s[0] == ' ') s = s.substr(1, s.size());
	// deleting spaces at the end
	while (s[s.size() - 1] == ' ') s = s.substr(0, s.size() - 1);
	// deleting additional spaces
	int i = 1;
	while (i < s.size()) {
		if (s[i] == ' ' && s[i - 1] == ' ') {
			s = s.substr(0, i) + s.substr(i + 1, s.size());
			--i;
		}
		++i;
	}
	// counting spaces
	i = 0;
	int spaces = 0;
	while (i++ < s.size()) if (s[i] == ' ')  ++spaces;
	int words = spaces + 1;
	return words;
}

int wordsInFile(const string& filename) {
	ifstream f(filename);
	string curr_string;
	int summ = 0;
	while (getline(f, curr_string)) {
		cout << curr_string << endl;
		summ += wordCount(curr_string);
	}
	f.close();
	return summ;
}


string deleteWord(string& s, const string& word) {
	int word_length = word.size();
	int pos = s.find(word);
	while (pos != -1) {
		s = s.substr(0, pos) + s.substr(pos + word_length + 1);
		pos = s.find(word);
	}
	string res = s;
	return res;
}


void deleteWordInFile(const string& filename, const string& word) {
	ifstream f(filename);
	if (!f.is_open()) cout << "Fail during opening" << endl;
	ofstream f1("result.txt", ios::trunc);
	string curr_string;
	while (getline(f, curr_string)) {
		f1 << deleteWord(curr_string, word) << endl;
	}
	f.close();
	f1.close();

}

string replaceWordWithNumberInString(string& s, const string& word, int& number) {
	int word_length = word.size();
	int pos = s.find(word);
	while (pos != -1) {
		s = s.substr(0, pos) + to_string(number) + ' ' + s.substr(pos + word_length + 1);
		++number;
		pos = s.find(word);
	}
	string res = s;
	return res;
}

void replaceWordWithNumberInFile(const string& filename, const string& word) {
	ifstream f(filename);
	if (!f.is_open()) cout << "Fail during opening" << endl;
	ofstream f1("result.txt", ios::trunc);
	string curr_string;
	int number = 0;
	while (getline(f, curr_string)) {
		f1 << replaceWordWithNumberInString(curr_string, word, number) << endl;
	}
	f.close();
	f1.close();
}


int main()
{
	/*
	// Test 1
	string filename1 = "test.txt";
	cout << symbCount(filename1) << endl;
	// Test 2
	string filename2 = "test.txt";
	cout << longestLine(filename2) << endl;
	*/
	// Test 3
	string filename3 = "test.txt";
	cout << wordCount(filename3) << endl;
	
	// in order to test task 4 and task 5 you should run Test 4 and Test 5 one by one. Not both at the same time.
	// Test 4
	string filename4 = "test.txt";
	string word4 = "love";
	deleteWordInFile(filename4, word4);
	// Test 5
	string filename5 = "test.txt";
	string word5 = "love";
	replaceWordWithNumberInFile(filename5, word5);
	
	
	return 0;
}

