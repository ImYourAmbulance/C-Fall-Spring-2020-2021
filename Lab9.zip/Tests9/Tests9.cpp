#include "pch.h"
#include "CppUnitTest.h"
#include "../Lab9/Header.h"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Tests9
{
	TEST_CLASS(Tests9)
	{
	public:
		
		TEST_METHOD(Task3_1)
		{
			int* x = new int[4] {1, 2, 4, 5};
			int* y = new int;
			y = insert_element(x, 3, 4);
			bool flag = true;
			for (int i = 0; i < 5; ++i) {
				Assert::AreEqual(y[i], i + 1);
			}
			delete[] x;
			delete[] y;
			x = y = nullptr;
		}
		TEST_METHOD(Task3_2)
		{
			int* x = new int[3]{ 1, 2, 4 };
			int* y = new int;
			y = insert_element(x, 3, 3);
			bool flag = true;
			for (int i = 0; i < 4; ++i) {
				Assert::AreEqual(y[i], i + 1);
			}
			delete x;
			delete y;
			x = y = nullptr;
		}

		TEST_METHOD(Task4_1)
		{
			int* x = new int[12]{ 1, 1, 2, 2, 3, 3, 3, 4, 5, 5, 5 };
			size_t n = 12;
			int* y = deleting_duplicates(x, n);
			for (int i = 0; i < n; ++i) {
				Assert::AreEqual(y[i], i + 1);
			}
		}
		TEST_METHOD(Task4_2)
		{
			int* x = new int[6]{ 1, 2, 3, 4, 4,5 };
			size_t n = 6;
			int* y = deleting_duplicates(x, n);
			for (int i = 0; i < n; ++i) {
				Assert::AreEqual(y[i], i + 1);
			}
		}
		TEST_METHOD(Task5_1_1)
		{
			int* a = new int[5]{ 1, 2, 3, 4, 5 };
			size_t n = 5;
			Assert::IsTrue(is_sorted(a, n));
		}
		TEST_METHOD(Task5_1_2)
		{
			int* a = new int[5]{ 1, 3, 2, 4, 5 };
			size_t n = 5;
			Assert::IsFalse(is_sorted(a, n));
		}
		TEST_METHOD(Task5_2_1)
		{
			int* source = new int[10]{ 1, 2, 3, 4, 5, 7, 14, 21, 25, 25};
			int n = 10;
			int element = 21;
			int m;
			Assert::IsTrue(binary_search1(source, n, element, m));
		}
		TEST_METHOD(Task5_2_2)
		{
			int* source = new int[10]{ 1, 2, 3, 4, 5, 7, 14, 22, 25, 25 };
			int n = 10;
			int element = 21;
			int m;
			Assert::IsFalse(binary_search1(source, n, element, m));
		}
	};
}
