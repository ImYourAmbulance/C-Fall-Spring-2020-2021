#pragma once
int OnesCount(int n, int k = 0);
double Degree(double x, int n);
int Factorial(int n);
double BizareFunction(double x, int n);
int MaxDigit(int n);
int Add3ToNumber(int n, int k = 0, bool first_time = true);
int SquareWithoutMult(int n, int k = 2);
double OddSquareRoot(int n, int x = 0);
double EvenSquareRoot(int n, int x = 0);
double OddFraction(int n, int x = 1);
double EvenFraction(int n, int x = 2);
int MinDigit(int n, int k = 1);
bool IsHere7(int n);
int Remain(int x, int y, bool f = 1);