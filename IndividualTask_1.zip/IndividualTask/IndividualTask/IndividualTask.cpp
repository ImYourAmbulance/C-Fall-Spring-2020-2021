// IndividualTask.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
using namespace std;

int OnesCount(int n, int k = 0) {
	// variable k stands for total of all remainders happened due to dividing by 2
	if (n != 0) {
		k += (n % 2);
		return OnesCount(n / 2, k);
	}
	// if n became equal to zero we have nothing to do but to return last remainder
	else {
		return k;
	}
}
double Degree(double x, int n) {
	// I can't even possibly comment on that
	if (n == 0) 
		return 1;
	else 
		return x * Degree(x, n - 1);
}
int Factorial(int n) {
	if (n == 1 || n == 0) {
		return 1;
	}
	else {
		return n * Factorial(n - 1);
	}
}
double BizareFunction(double x, int n) {
	// this function makes the final fraction that is required in task #3
	return Degree(x, n) / Factorial(n);
}
int MaxDigit(int n) {
	// given a number n. We are going to compare all its digits and choose the bigger one
	if (n != 0) {
		return (abs(n % 10) > abs(MaxDigit(n / 10))) ? abs(n % 10) : abs(MaxDigit(n / 10));
	}
	else {
		return 0;
	}
}
int Add3ToNumber(int n, int k = 0, bool first_time = true) {
	++k;
	
	if (n == 0) {
		if (first_time) {
			// if n is initially equal to zero we'd make k = 2 and by that we 
			// just multiply 3 by 10
			k = 2;
		}
		return 3 * pow(10, k - 1);
	}
	else {
		return (n % 10) * pow(10, k - 1) + Add3ToNumber(n / 10, k, false);
	}
}
int SquareWithoutMult(int n, int k = 2) {
	if (k == 1)
		return abs(n);
	int s = 0;
	for (int i = 0; i < abs(n); ++i) {
		s += (SquareWithoutMult(n, 1));
	}
	return s;
}
double OddSquareRoot(int n, int x = 0) {
	if (!x) {
		x = 2 * n + 1;
	}
	if (2 * n > 0) {
		return sqrt(x - 2 * n + OddSquareRoot(n - 1, x));
	}
	else {
		return sqrt(x);
	}
}
double EvenSquareRoot(int n, int x = 0) {
	if (!x)
		x = 2 * n;
	if (2 * n - 2 > 0) {
		return sqrt(x - (2 * n + 2) + EvenSquareRoot(n - 1, x));
	}
	else {
		return sqrt(x);
	}
}
double OddFraction(int n, int x = 1) {
	if (x < n) {
		return (1 / (x + OddFraction(n, x + 1)));
	}
	else {
		return 1.0 / n;
	}

}
double EvenFraction(int n, int x = 2) {
	if (x < 2 * n) {
		return (1 / (x + EvenFraction(n, x + 2)));
	}
	else {
		return 1.0 / 2 / n;
	}
}
int MinDigit(int n, int k = 1) {
	// given a number n.We are going to compare all its digitsand choose the lesser one
	/*i need variable k because it plays a role of flag that say whether n was
	  initially equal to zero or not
	*/
	if (n != 0) {
		return (abs(n % 10) < abs(MinDigit(n / 10, 0))) ? abs(n % 10) : abs(MinDigit(n / 10, 0));
	}
	else {
		return k == 1 ? abs(n) : 9;
	}
}
bool IsHere7(int n)	 {
	// if we find 7 at least once, then the logic expression is true
	// else it is false
	if (abs(n) > 0) {
		return (abs(n % 10) == 7) || IsHere7(n / 10);
	}
	else {
		return false;
	}
}
int Remain(int x, int y, bool first_time = 1) {
	// let's say we have 7 and 3
	// we are about to substract second number from first while
	// second one is lesser than first one
	// so, once second one is bigger than first one we return first number what it is 1
	if (x < y) {
		if (!first_time) {
			// however if it's first time and x < y then it's clear that remainder is
			// is equal to first number
			return x;
		}
		else {
			return y;
		}
	}
	else {
		return Remain(x - y, y, 0);
	}
}

int main() {
	return 0;
}

