#include "pch.h"
#include "CppUnitTest.h"
#include "../IndividualTask/Functions.h"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Tests
{
	TEST_CLASS(Tests)
	{
	public:
		TEST_METHOD(Task1_1)
		{
			Assert::AreEqual(OnesCount(0), 0);
		}
		TEST_METHOD(Task1_2)
		{
			Assert::AreEqual(OnesCount(1), 1);
		}
		TEST_METHOD(Task1_3)
		{
			Assert::AreEqual(OnesCount(7), 3);
		}
		TEST_METHOD(Task2_1)
		{
			Assert::AreEqual(BizareFunction(1, 2), 0.5, 0.001);
		}
		TEST_METHOD(Task2_2)
		{
			Assert::AreEqual(BizareFunction(0, 2), 0, 0.001);
		}
		TEST_METHOD(Task2_3)
		{
			Assert::AreEqual(BizareFunction(2, 2), 2.0, 0.001);
		}
		TEST_METHOD(Task3_1)
		{
			Assert::AreEqual(MaxDigit(0), 0);
		}
		TEST_METHOD(Task3_2)
		{
			Assert::AreEqual(MaxDigit(12445), 5);
		}
		TEST_METHOD(Task3_3)
		{
			Assert::AreEqual(MaxDigit(-12445), 5);
		}
		TEST_METHOD(Task4_1)
		{
			Assert::AreEqual(Add3ToNumber(0), 30);
		}
		TEST_METHOD(Task4_3)
		{
			Assert::AreEqual(Add3ToNumber(2340), 32340);
		}
		TEST_METHOD(Task5_1)
		{
			Assert::AreEqual(SquareWithoutMult(0), 0);
		}
		TEST_METHOD(Task5_2)
		{
			Assert::AreEqual(SquareWithoutMult(-1), 1);
		}
		TEST_METHOD(Task5_3)
		{
			Assert::AreEqual(SquareWithoutMult(1), 1);
		}
		TEST_METHOD(Task6_1)
		{
			Assert::AreEqual(OddSquareRoot(1), sqrt(1 + sqrt(3)), 0.1);
		}
		TEST_METHOD(Task6_2)
		{
			Assert::AreEqual(OddSquareRoot(1), sqrt(1 + sqrt(3)), 0.1);
		}
		TEST_METHOD(Task6_3)
		{
			Assert::AreEqual(OddSquareRoot(2), sqrt(1 + sqrt(3 + sqrt(5))), 0.1);
		}
		TEST_METHOD(Task7_1)
		{
			Assert::AreEqual(EvenSquareRoot(1), sqrt(2), 0.1);
		}
		TEST_METHOD(Task7_2)
		{
			Assert::AreEqual(EvenSquareRoot(2), sqrt(2 + sqrt(4)), 0.1);
		}
		TEST_METHOD(Task8_1)
		{
			Assert::AreEqual(OddFraction(1), 1.0, 0.1);
		}
		TEST_METHOD(Task8_2)
		{
			Assert::AreEqual(OddFraction(2), 0.667, 0.1);
		}
		TEST_METHOD(Task9_1)
		{
			Assert::AreEqual(EvenFraction(1), 0.5, 0.1);
		}
		TEST_METHOD(Task9_2)
		{
			Assert::AreEqual(EvenFraction(2), 4.0 / 9, 0.1);
		}
		TEST_METHOD(Task10_1)
		{
			Assert::AreEqual(MinDigit(0), 0);
		}
		TEST_METHOD(Task10_2)
		{
			Assert::AreEqual(MinDigit(45), 4);
		}
		TEST_METHOD(Task10_3)
		{
			Assert::AreEqual(MinDigit(-12445), 1); 
		}
		TEST_METHOD(Task11_1)
		{
			Assert::AreEqual(Remain(23, 12), 11);
		}
		TEST_METHOD(Task11_2)
		{
			Assert::AreEqual(Remain(25, 12), 1);
		}
		TEST_METHOD(Task11_3)
		{
			Assert::AreEqual(Remain(12, 13), 13); 
		}
		TEST_METHOD(Task12_1)
		{
			Assert::IsTrue(IsHere7(3435721));
		}
		TEST_METHOD(Task12_2)
		{
			Assert::IsFalse(IsHere7(3435421));
		}
		TEST_METHOD(Task12_3)
		{
			Assert::IsTrue(IsHere7(-7));
		}
	};
}
