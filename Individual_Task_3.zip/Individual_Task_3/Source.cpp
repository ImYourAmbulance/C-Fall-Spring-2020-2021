#include <iostream>
#include <string>
#include <fstream>
#include "Header.h"

using namespace std;

struct exam {
    char fullname[128] = "No Name";
    int number = 0;
    int exam_res[3] = { 0, 0, 0 };

};

void maxSubsequence(char* source, char* start, int& subs_len) {
    start = source;
    char* max_subseq_start = source;
    char* curr_subseq_start = source;
    int max_len = 0, curr_len = 0;
    while (start) {
        if (*(start)++ == ' ') {
            if (curr_len > max_len) {
                max_len = curr_len;
                curr_len = 0;
                max_subseq_start = curr_subseq_start;
                curr_subseq_start = ++start;
            }
            else {
                if (*(start) != ' ') ++curr_len;
            }
        }
    }
    subs_len = max_len;

}

string changeSpaces(string& line) {
    int spaces =0 ;
    size_t size = line.size();
    for (int i = 0; i < size; ++i) if (line[i] == ' ') ++spaces;
    return to_string(spaces) + ' ' + line;
}

void spacesDetecting(const string& filename) {
    ifstream file(filename + ".txt");
    ofstream result("result.txt");
    string line;
    while (getline(file, line)) {
        result << changeSpaces(line) << endl;
    }
    file.close();
    result.close();
}

void insertStudentsinDat(const string& filename) {
    ofstream file(filename + ".dat", ios::binary);
    exam student;
    cout << "How many students do you want to input?" << endl;
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cout << "Input name of a student number " << i + 1 << endl;
        cin.ignore(1);
        cin.getline(student.fullname, 128);
        cout << "Input the student's number " << endl;
        cin >> student.number;
        cout << "Input 3 grades" << endl;
        for (int j = 0; j < 3; ++j) cin >> student.exam_res[j];
        file.write(reinterpret_cast<char*>(&student), sizeof(exam));
    }
    file.close();
}

void readtStudentsfromDat(const string& filename) {
    ifstream file(filename + ".dat", ios::binary);
    exam student;
    int i = 0;
    while (file.read(reinterpret_cast<char*>(&student), sizeof(exam))) {
        cout << "__________________________________" << endl;
        cout << "Name " << student.fullname << endl;
        cout << "Number " << student.number << endl;
        cout << "Grades " << student.exam_res[0] << " " << student.exam_res[1] << " " << student.exam_res[2] << endl;
        cout << "__________________________________" << endl;
    }
    file.close();
}

void printQuitters(const string& filename) {
    ifstream file(filename + ".dat", ios::binary);
    int i = 1;
    exam student; while (file.read(reinterpret_cast<char*>(&student), sizeof(exam))) {
        
        if (student.exam_res[0] < 3 || student.exam_res[1] < 3 || student.exam_res[2] < 3) {
            cout << "Loser number " << i++ << endl;
            cout << "Name " << student.fullname << endl;
            cout << "Number " << student.number << endl;
            cout << "Grades " << student.exam_res[0] << " " << student.exam_res[1] << " " << student.exam_res[2] << endl;
        }
    }
    file.close();
} 

void changeExamGrade(const string& filename, int number, int subject, int new_grade) {
    fstream file(filename + ".dat", ios::binary | ios::in | ios::out);
    exam student;
    streampos pos = file.tellg();
    while (file.read(reinterpret_cast<char*>(&student), sizeof(exam))) {
        if (student.number == number) {
            // I have a strange problem - when I write the changed student in the file nothing changes
            student.exam_res[subject] = new_grade;
            file.seekp(pos);
            file.write(reinterpret_cast<char*>(&student), sizeof(exam));
            file.close();
            return;
        }
        streampos pos = file.tellg();
    }
    file.close();
}