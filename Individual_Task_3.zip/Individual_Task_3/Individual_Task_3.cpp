﻿#include <iostream>
#include <string>
#include <fstream>
#include "Header.h"

using namespace std;



int main()
{
    // Task 1
    /*
    string filename = "test";
    spacesDetecting(filename);
    */
    // Task 1
    string filename = "test";
    insertStudentsinDat(filename);
    printQuitters(filename);
    readtStudentsfromDat(filename);
    // I am changing here a grade of student number 1 on subject number 0 (=1)
    int number = 1, subject = 0, new_grade = 4;
    changeExamGrade(filename, number, subject, new_grade);
    readtStudentsfromDat(filename);
    return 0;
}

