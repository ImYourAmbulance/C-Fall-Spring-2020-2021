#pragma once
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

struct exam;

void maxSubsequence(char* source, char* start, int& subs_len);

string changeSpaces(string& line);

void spacesDetecting(const string& filename);

void insertStudentsinDat(const string& filename);

void readtStudentsfromDat(const string& filename);

void printQuitters(const string& filename);

void changeExamGrade(const string& filename, int number, int subject, int new_grade);