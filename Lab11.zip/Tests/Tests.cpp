#include "pch.h"
#include "CppUnitTest.h"
#include "../Lab11/Header.h"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Tests
{
	TEST_CLASS(Task1)	
	{
	public:
		TEST_METHOD(Test1)
		{
			matrix a = {
				{1, 2, 3, 4},
				{0, 0, 0, 0},
				{1, 0 ,2, 0},
				{0, 0, 0, 0}
			};
			Assert::AreEqual(zeroCounting(a, 4, 4), 2);
		}
		TEST_METHOD(Test2)
		{
			matrix a = {
				{1, 2, 3, 4},
				{1, 0, 0, 0},
				{1, 0 ,2, 0},
				{0, 0, 0, 1}
			};
			Assert::AreEqual(zeroCounting(a, 4, 4), 0);
		}
		TEST_METHOD(Test3)
		{
			matrix a = {
				{0, 0, 0, 0},
				{0, 0, 0, 0},
				{0, 0, 0, 0},
				{0, 0, 0, 0}
			};
			Assert::AreEqual(zeroCounting(a, 4, 4), 4);
		}
	};
	TEST_CLASS(Task2)
	{
	public:
		TEST_METHOD(Test1)
		{
			matrix old_one = {
				{1, 2, 3, 4},
				{5, 6, 7, 8},
				{9, 10, 11, 12},
				{13, 14, 15, 16}
			};
			matrix new_one = {
				{5, 6, 7, 8},
				{9, 10, 11, 12},
				{13, 14, 15, 16},
				{13, 14, 15, 16}
			};
			deleteFirstRow(old_one, 4, 4);
			// we delete the first row, so now we have only 3 rows
			for (int i = 0; i < 3; ++i) {
				for (int j = 0; j < 4; ++j) {
					Assert::AreEqual(old_one[i][j], new_one[i][j]);
				}
			}
		}
	};
	TEST_CLASS(Task3)
	{
	public:
		TEST_METHOD(Test1)
		{
			matrix a = {
				{1, 2, 3, 4},
				{5, 6, 7, 8},
				{9, 10, 11, 12},
				{13, 14, 15, 16}
			};
			matrix result = {
				{9, 9, 9, 9},
				{1, 2, 3, 4},
				{5, 6, 7, 8},
				{9, 10, 11, 12},
			};
			int row[4] = { 9,9,9,9 };
			// placing the new row on position number zero
			// and shifting rows down 
			insertRow(a, row, 0, 4, 4);
			// checking 
			for (int i = 0; i < 4; ++i) {
				for (int j = 0; j < 4; ++j) {
					Assert::AreEqual(result[i][j], a[i][j]);
				}
			}
		}
	};
	TEST_CLASS(Task4)
	{
	public:
		TEST_METHOD(Test1)
		{
			matrix matr = {
				{1, 2, 3, 4},
				{5, 6, 7, 8},
				{9, 10, 11, 12},
				{13, 14, 15, 16}
			};
			matrix old_matr = {
				{1, 2, 3, 4},
				{5, 6, 7, 8},
				{9, 10, 11, 12},
				{13, 14, 15, 16}
			};
			transposeMatrix(matr, 4, 4);
			for (int i = 0; i < 4; ++i) {
				for (int j = 0; j < 4; ++j) {
					Assert::AreEqual(matr[j][i],old_matr[i][j]);
				}
			}
		}
	};
}
