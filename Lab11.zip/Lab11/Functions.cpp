#include <iostream>
#include <iomanip>

using namespace std;

const int MAX_ROWS = 10;
const int MAX_COLS = 10;
typedef int matrix[MAX_ROWS][MAX_COLS];

int zeroCounting(matrix matr, int rows, int cols) {
	int zeros = 0;
	bool f;
	for (int i = 0; i < rows; ++i) {
		f = true;
		for (int j = 0; j < cols; ++j) {
			if (matr[i][j] != 0) {
				f = false;
			}
		}
		if (f) {
			++zeros;
		}
	}
	return zeros;
}

void deleteFirstRow(matrix matr, int rows, int cols) {
	// shifting up all rows on 1 position higher
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			if (i > 0) {
				matr[i - 1][j] = matr[i][j];
			}
		}
	}
}
void insertRow(matrix matr, int* row, int k, int rows, int cols) {
	// shifting down all rows with index lesser than k
	for (int i = rows - 1; i >= k; --i) {
		for (int j = 0; j < cols; ++j) {
			matr[i + 1][j] = matr[i][j];
		}
	}

	// writing the k row in the array
	for (int i = 0; i < cols; ++i) {
		matr[k][i] = row[i];
	}
}
void transposeMatrix(matrix matr, int rows, int cols) {
	for (int i = 0; i < rows; ++i) {
		for (int j = i; j < cols; ++j) {
			swap(matr[i][j], matr[j][i]);
		}
	}
}

void printMatrix(matrix matr, int rows, int cols) {
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j < cols; ++j) {
			std::cout << matr[i][j] << " ";
		}
		std::cout << std::endl;
	}
}

