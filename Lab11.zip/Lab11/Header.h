#pragma once
const int MAX_ROWS = 10;
const int MAX_COLS = 10;
typedef int matrix[MAX_ROWS][MAX_COLS];

int zeroCounting(matrix matr, int rows, int cols);

void deleteFirstRow(matrix matr, int rows, int cols);
void insertRow(matrix matr, int* row, int k, int rows, int cols);
void transposeMatrix(matrix matr, int rows, int cols);
void printMatrix(matrix matr, int rows, int cols);