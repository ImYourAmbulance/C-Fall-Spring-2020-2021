#include <iostream>
#include "../Lab11/Header.h"
using namespace std;

int main()
{
	matrix a = {
				{1, 2, 3, 4},
				{5, 6, 7, 8},
				{9, 10, 11, 12},
				{13, 14, 15, 16}
	};
	matrix result = {
		{ 9,9,9,9 },
		{1, 2, 3, 4},
		{5, 6, 7, 8},
		{9, 10, 11, 12}
	};
	int row[4] = { 9,9,9,9 };
	// placing the new row on position number zero
	insertRow(a, row, 0, 4, 4);
	printMatrix(a, 4, 4);
	return 0;
}
