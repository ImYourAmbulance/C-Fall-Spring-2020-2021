#pragma once
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
using namespace std;


struct point {
	double x, y;
};

struct date {
	int day;
	int month;
	int year;
};
struct person
{
	char fullname[128];
	date birthday;
	char gender;
};

void findTheMostDistancedPoints(const string& filename);

void insertStaffData(string& filename);