#include "Header.h"

int main()
{
	// first example
	string filename = "points.txt";
	findTheMostDistancedPoints(filename);
	// second one
	filename = "staff.txt";
	insertStaffData(filename);
	return 0;
}


