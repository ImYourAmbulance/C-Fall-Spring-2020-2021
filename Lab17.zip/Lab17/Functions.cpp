#include "Header.h"

void findTheMostDistancedPoints(const string& filename) {
	ifstream file(filename);
	int n; 
	file >> n;
	point* a = new point[n];
	double x, y;
	for (int i = 0; i < n; ++i) {
		file >> x >> y;
		a[i] = point{ x, y };
	}
	file.close();
	double distance = 0;
	double max_distance = 0;
	point first_point, second_point;
	for (int i = 0; i < n; ++i) {
		for (int j = i + 1; j < n; ++j) {
			distance = (sqrt((a[i].x - a[j].x) * (a[i].x - a[j].x) + (a[i].y - a[j].y) * (a[i].y - a[j].y)));
			if ((distance - max_distance) > 0.001) {
				max_distance = distance;
				first_point = a[i];
				second_point = a[j];
			}
		}
	}
	cout << "Here are two points with the maximum distance between them" << endl;
	cout << "(" << first_point.x << ", " << first_point.y << ") and " << "(" << second_point.x << ", " << second_point.y << ")" << endl;
}

void insertStaffData(string& filename) {
	cout << "Enter number of stuff you'd like to add in your file" << endl;
	int n;
	cin >> n;
	person* staff_to_add = new person[n];
	date birthday;
	int year, month, day;
	char fullname[128];
	char gender;
	person current_person;
	ofstream file(filename);
	for (int i = 0; i < n; ++i) {
		cout << "Enter the information about worker number " << i << endl;
		cout << "Year, month, day of birth - ";
		cin >> birthday.year >> birthday.month >> birthday.day;
		cout << endl << "Gender (one letter) - ";
		cin >> current_person.gender;
		cout << endl << "Full name - ";
		cin >> current_person.fullname;
		cout << endl;
		current_person.birthday = birthday;
		staff_to_add[i] = current_person;
		// well, we have inserted a staff member in the array, now it's time to put it in a file
		file << staff_to_add[i].fullname << " | " << staff_to_add[i].birthday.day << "."
			 << staff_to_add[i].birthday.month << "." << staff_to_add[i].birthday.year << " | "
			 << staff_to_add[i].gender << endl;
	}
	file.close();
}