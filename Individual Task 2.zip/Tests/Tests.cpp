#include "pch.h"
#include "CppUnitTest.h"
#include "..\Individual Task 2\Header.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Tests
{
	TEST_CLASS(Test1)
	{
	public:
		TEST_METHOD(TestMethod1)
		{
			int a[] = { 1, 2, 3, 4 ,5 };
			int n = 5;
			Assert::AreEqual(isThereZeroInArray(a, n), false);
		}
		TEST_METHOD(TestMethod2)
		{
			int a[] = { 1, 2, 3, 4 ,0 };
			int n = 5;
			Assert::AreEqual(isThereZeroInArray(a, n), true);
		}
		TEST_METHOD(TestMethod3)
		{
			int a[] = { 0};
			int n = 1;
			Assert::AreEqual(isThereZeroInArray(a, n), true);
		}
	};
	TEST_CLASS(Test2)
	{
	public:
		TEST_METHOD(TestMethod1)
		{
			int* a = new int[5]{ 5, 5, 1, 4, 4 };
			int n = 5;
			int* res = deleteBeforeMin(a, n);
			for (int i = 0; i < n; ++i) {
				Assert::AreEqual(a[i], res[i]);
			}
		}
		TEST_METHOD(TestMethod2)
		{
			int* a = new int[5]{ 5, 5, 1, 4, 4 };
			int n = 5;
			int* res = deleteBeforeMin(a, n);
			for (int i = 0; i < n; ++i) {
				Assert::AreEqual(a[i], res[i]);
			}
		}
		TEST_METHOD(TestMethod3)
		{
			int* a = new int[5]{ 1, 5, 5, 5, 5 };
			int n = 5;
			int* res = deleteBeforeMin(a, n);
			for (int i = 0; i < n; ++i) {
				Assert::AreEqual(a[i], res[i]);
			}
		}
	};
	TEST_CLASS(Test3)
	{
	public:
		TEST_METHOD(TestMethod1)
		{
			int n = 5;
			int* a = new int[n]{ 1, 2, 3, 4 ,5 };
			Assert::AreEqual(pairsOfSameElements(a, n), 0);

		}
		TEST_METHOD(TestMethod2)
		{
			int n = 5;
			int* a = new int[n] { 1, 2, 3, 3, 5 };
			Assert::AreEqual(pairsOfSameElements(a, n), 1);
		}
		TEST_METHOD(TestMethod3)
		{
			int n = 5;
			int* a = new int[n] { 1, 1, 1, 1, 1 };
			Assert::AreEqual(pairsOfSameElements(a, n), 4);
		}
	};
	TEST_CLASS(Test4)
	{
	public:
		TEST_METHOD(TestMethod1)
		{
			int rows =4, cols = 4;
			int** a = nullptr;
			a = new int*[rows];
			for (int i = 0; i < rows; ++i) a[i] = new int[cols];

			for (int i = 0; i < rows; ++i) {
				for (int j = 0; j < cols; ++j) {
					a[i][j] = 0;
				}
			}
			Assert::AreEqual(Multiplication(a, 4, 4), 0);
			for (int i = 0; i < rows; ++i) delete[] a[i];
			delete[] a;
		}
		TEST_METHOD(TestMethod2)
		{
			int rows = 4, cols = 4;
			int** a = nullptr;
			a = new int* [rows];
			for (int i = 0; i < rows; ++i) a[i] = new int[cols];

			for (int i = 0; i < rows; ++i) {
				for (int j = 0; j < cols; ++j) {
					a[i][j] = i * 2;
				}
			}

			Assert::AreEqual(Multiplication(a, 4, 4), 0);

			for (int i = 0; i < rows; ++i) delete[] a[i];
			delete[] a;
		}
		TEST_METHOD(TestMethod3)
		{
			int rows = 4, cols = 4;
			int** a = nullptr;
			a = new int* [rows];
			for (int i = 0; i < rows; ++i) a[i] = new int[cols];

			for (int i = 0; i < rows; ++i) {
				for (int j = 0; j < cols; ++j) {
					a[i][j] = 2;
				}
			}
			Assert::AreEqual(Multiplication(a, 4, 4), 64);

			for (int i = 0; i < rows; ++i) delete[] a[i];
			delete[] a;
		}
	};
	TEST_CLASS(Test5)
	{
	public:
		TEST_METHOD(TestMethod1)
		{
			int rows = 4, cols = 4;
			int** a = nullptr;
			a = new int* [rows];
			for (int i = 0; i < rows; ++i) a[i] = new int[cols];

			for (int i = 0; i < rows; ++i) {
				for (int j = 0; j < cols; ++j) {
					a[i][j] = 0;
				}
			}

			int* b = VectorOfZeros(a, rows, cols);
			int result[4] = { 0,0,0,0 };

			for (int i = 0; i < rows; ++i) {
				Assert::AreEqual(result[i], b[i]);
			}

			for (int i = 0; i < rows; ++i) delete[] a[i];
			delete[] a;
			delete[] b;
		}
		TEST_METHOD(TestMethod2)
		{
			int rows = 4, cols = 4;
			int** a = nullptr;
			a = new int* [rows];
			for (int i = 0; i < rows; ++i) a[i] = new int[cols];

			for (int i = 0; i < rows; ++i) {
				for (int j = 0; j < cols; ++j) {
					a[i][j] = i * j;
				}
			}

			int* b = VectorOfZeros(a, rows, cols);
			int result[4] = { 0,3,3,3 };

			for (int i = 0; i < rows; ++i) {
				Assert::AreEqual(result[i], b[i]);
			}

			for (int i = 0; i < rows; ++i) delete[] a[i];
			delete[] a;
			delete[] b;
		}
		TEST_METHOD(TestMethod3)
		{
			int rows = 4, cols = 4;
			int** a = nullptr;
			a = new int* [rows];
			for (int i = 0; i < rows; ++i) a[i] = new int[cols];
			
			for (int i = 0; i < rows; ++i) {
				for (int j = 0; j < cols; ++j) {
					a[i][j] = 1;
				}
			}

			int* b = VectorOfZeros(a, rows, cols);
			int result[4] = { 4,4,4,4 };

			for (int i = 0; i < rows; ++i) {
				Assert::AreEqual(result[i], b[i]);
			}

			for (int i = 0; i < rows; ++i) delete[] a[i];
			delete[] a;
			delete[] b;
		}
	};
}
