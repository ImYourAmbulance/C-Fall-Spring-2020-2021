#include "Header.h"

int main()
{ 
	int n = 5;
	int* a = new int[n] { 1, 1, 1, 1, 1 };
	pairsOfSameElements(a, n);
	return 0;
}
