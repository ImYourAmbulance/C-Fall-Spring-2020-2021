#include "Header.h"

bool isThereZeroInArray(int* a, int n) {
	for (int i = 0; i < n; ++i) if (a[i] == 0) return true;
	return false;
}

int* deleteBeforeMin(int*& a, int& n) {
	int min;
	int min_ind;
	for (int i = 0; i < n; ++i) {
		if (i == 0) {
			min = a[0];
			min_ind = 0;
		}
		if (a[i] > min) {
			min = a[i];
			min_ind = i;
		}
	}
	int* new_arr = min_ind > 0 ? new int[min_ind] : nullptr;
	for (int i = 0; i < min_ind; ++i) {
		new_arr[i] = a[i];
	}
	n = min_ind;
	return new_arr;
}

int pairsOfSameElements(int*& a, int n) {
	if (n < 2) return 0;
	else {
		return (a[0] == a[1]) + pairsOfSameElements(++a, n - 1);
	}
}

int Multiplication(int** a, int rows, int cols) {
	int m = 1;
	for (int i = 0; i < rows; ++i) {
		for (int j = 0; j <= i; ++j) {
			if ((a[i][j] % 2 == 0) && j < (rows - i)) {
				m *= a[i][j];
			}
		}
	}
	return m;
}

int* VectorOfZeros(int** a, int rows, int cols) {
	int* v = new int[cols];
	int zeros_in_row;
	for (int i = 0; i < rows; ++i) {
		zeros_in_row = 0;
		for (int j = 0; j < cols; ++j) {
			if (a[i][j] != 0) ++zeros_in_row;
		}
		v[i] = zeros_in_row;
	}
	return v;
}
