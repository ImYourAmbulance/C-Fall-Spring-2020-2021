#pragma once
#include <iostream>

using namespace std;

bool isThereZeroInArray(int* a, int n);

int* deleteBeforeMin(int*& a, int& n);

int pairsOfSameElements(int*& a, int n);

int Multiplication(int** a, int rows, int cols);
 
int* VectorOfZeros(int** a, int rows, int cols);