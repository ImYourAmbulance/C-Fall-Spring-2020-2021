#include "pch.h"
#include "CppUnitTest.h"
#include "../Lab10/Header.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Tests10
{
	TEST_CLASS(Tests10_1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
		}
	};
	TEST_CLASS(Tests10_2)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
		}
	};
	TEST_CLASS(Tests10_3)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
		}
	};
	TEST_CLASS(Tests10_4)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
		}
	};
	TEST_CLASS(Tests10_5)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
		}
	};
}
