#include "pch.h"
#include "CppUnitTest.h"
#include "../Lab10/Header.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Tests10
{
	TEST_CLASS(Tests10_1)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
			int* x = new int[5]{ 1, 2, 3, 4, 0 };
			int n = 5;
			bool catched = false;
			try {
				double r = ratio(x, n);
				cout << r;
			}
			catch (runtime_error& error) {
				catched = true;
			}
			Assert::IsTrue(catched);
			delete[] x;
			x = nullptr;
		}
		TEST_METHOD(TestMethod2)
		{
			int* x = new int[6]{ 1, 3, 0, 4, 0 };
			int n = 6;
			bool catched = false;
			try {
				double r = ratio(x, n);
				cout << r;
			}
			catch (runtime_error& error) {
				catched = true;
			}
			Assert::IsFalse(catched);
			delete[] x;
			x = nullptr;
		}
	};
	TEST_CLASS(Tests10_2)
	{
	public:
		TEST_METHOD(TestMethod1)
		{
			double a = -1, b = 1;
			double pace = 0.1;
			bool catched = false;
			try {
				valuesOnSequence(badFun, a, b, pace);
			}
			catch (exception& error) {
				catched = true;
			}
			Assert::IsTrue(catched);

		}
		TEST_METHOD(TestMethod2)
		{
			double a = -1, b = 1;
			double pace = 0.1;
			bool catched = false;
			try {
				valuesOnSequence(goodFun, a, b, pace);
			}
			catch (exception& error) {
				catched = true;
			}
			Assert::IsFalse(catched);
		}
	};
	TEST_CLASS(Tests10_3)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
			string a = "8+11";
			bool catched = false;
			try {
				calculateIt(a);
			}
			catch (exception& error) {
				catched = true;
			}
			Assert::IsFalse(catched);
		}
		TEST_METHOD(TestMethod2)
		{
			string a = "8,11";
			bool catched = false;
			try {
				calculateIt(a);
			}
			catch (exception& error) {
				catched = true;
			}
			Assert::IsTrue(catched);
		}
		TEST_METHOD(TestMethod3)
		{
			string a = "8/0";
			bool catched = false;
			try {
				calculateIt(a);
			}
			catch (exception& error) {
				catched = true;
			}
			Assert::IsTrue(catched);
		}
	};
}