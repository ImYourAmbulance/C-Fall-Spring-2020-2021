#include <iostream>
#include <iomanip>
#include "Header.h"

int main()
{
	/*
	int* x = new int[5]{ 1, 2, 3, 4, 0};
	int n = 5;
	try {
		double r = Ratio(x, n);
		cout << r;
	}
	catch (runtime_error& error) {
		cout << error.what();
	}
	*/
	valuesOnSequence(goodFun, -1, 1, 0.1);
	return 0;
	
}

