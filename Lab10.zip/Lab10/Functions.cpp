#include <iostream>
#include <exception>
#include <iomanip>
#include <sstream>
#include "Header.h"

using namespace std;

int sumOfArray(int*& a, int l, int r) {
	int s = 0;
	for (int i = l; i <= r; ++i) {
		s += a[i];
	}
	return s;
}

double ratio(int*& a, int n) {
	bool zero_is_found = false;
	int i = 0;
	while (!zero_is_found && i < (n - 1)) {
		if (a[i] == 0) {
			zero_is_found = true;
		}
		++i;
	}
	--i;
	if (!zero_is_found) {
		throw runtime_error("Wrong input");
	}
	else {
		int s1 = sumOfArray(a, 0, i - 1);
		int s2 = sumOfArray(a, i + 1, n - 1);
		if (!s2) {
			throw runtime_error("You scared the shit out of me. That's division by zero, bruh");
		}
		return (s1 * 1.0) / s2;
	}
}

double badFun(double x) {
	if (abs(x -0.5) < 0.1) {
		throw runtime_error("Function is not defined");
	}
	return 1.0 / (x - 0.5);
}
double goodFun(double x) {
	return 2 * x;
}

void valuesOnSequence(double(*fun)(double), double a, double b, double pace) {
	for (; abs(b - a) > pace; a += pace) {
		cout << setw(5) << a << ' ' << setw(5) << (*fun)(a) << endl;
	}
}

double calculateIt(string& s) {
	stringstream stream(s);
	int a;
	stream >> a;
	if (stream.peek() != '*' && stream.peek() != '/' && stream.peek() != '+'
		&& stream.peek() != '-') {
		throw runtime_error("Wrong operation");
	}
	char operation_sign;
	stream >> operation_sign;
	int b;
	stream >> b;
	if (b == 0) {
		throw runtime_error("Hey, fool! Catch division by zero.");
	}
	double result;
	if (operation_sign == '*') {
		result = (a * 1.0) * b;
	}
	if (operation_sign == '/') {
		result = (a * 1.0) / b;
	}
	if (operation_sign == '+') {
		result = (a + b);
	}
	if (operation_sign == '-') {
		result = (a - b);
	}
	return result;
}

void read(int*& a, std::size_t& n) {
	if (a != NULL) {
		throw runtime_error("Pointer has been already used");
	}
	cout << "Enter size of your array" << endl;
	cin >> n;
	a = new int[n];
	for (size_t i = 0; i < n; ++i) {
		cin >> a[i];
	}
}