#pragma once
#include <iostream>
#include <exception>
using namespace std;
int sumOfArray(int*& a, int l, int r);
double ratio(int*& a, int n);
double badFun(double x);
double goodFun(double x);
void valuesOnSequence(double(*fun)(double), double a, double b, double pace);
double calculateIt(string& s);
void read(int*& a, std::size_t& n);