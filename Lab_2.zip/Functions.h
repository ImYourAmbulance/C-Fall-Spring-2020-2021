#pragma once
#include <iostream>
#include <cmath>
using namespace std;

void ChangeTheNumber(int n);
void ExploreNumber(int n, int& digits_sum, int& number_of_digits);
int Factorial(int n);
inline int max(int a, int b);
void swap(int& a, int& b);
void Regulation(int& a, int& b);
double CalculateSin(double angle);
int Degree(int x, int n);
bool Check(int n, int k);
int Max(int a, int b);
int Min(int a, int b);
