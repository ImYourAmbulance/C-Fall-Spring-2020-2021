#include <iostream>
#include <cmath>
#include "Functions.h"
using namespace std;

void ChangeTheNumber(int n) {
	cout << "Before " << n << endl;
	n /= 10;
	int new_n = 0;
	int d = 0;
	while (n / 10 > 0) {
		new_n = new_n + (n % 10) * pow(10, d);
		n /= 10;
		++d;
	}
	cout << "After " << new_n << endl;
}
void ExploreNumber(int n, int& digits_sum, int& number_of_digits) {
	while (n) {
		digits_sum += n % 10;
		++number_of_digits;
		n /= 10;
	}
	cout << "Summary of digits in n is equal to " << digits_sum << endl;
	cout << "Number of digits is equal to " << number_of_digits << endl;
}

int Factorial(int n) {
	if (n <= 1) {
		return n;
	}
	else return n * Factorial(n - 1);
}

inline int max(int a, int b) {
	return a > b ? a : b;
}

void swap(int& a, int& b) {
	int tmp = a;
	a = b;
	b = tmp;
}
void Regulation(int& a, int& b) {
	if (b > a) {
		swap(a, b);
	}
}


double CalculateSin(double angle) {
	double eps = 0.000001;
	double s = 0;
	long double next_element_of_s = angle;
	int k = 1;
	while (abs(next_element_of_s) >= eps) {
		s += next_element_of_s;
		// next_element_of_s = (pow(-1, k) * pow(angle, 2 * k  + 1)) / Factorial(2 * k  + 1);
		next_element_of_s *= -1 * pow(angle, 2) * Factorial(2 * k - 1);
		next_element_of_s /= Factorial(2 * k + 1);
		++k;
	}
	return s;
}

int Degree(int x, int n) {
	int new_x = 1;
	for (int i = 0; i < n; ++i) {
		new_x *= x;
	}
	return new_x;
}

bool Check(int n, int k) {
	int s = 0;
	int old_value = n;
	while (n) {
		s += Degree(n % 10, k);
		n /= 10;
	}
	return s == old_value;
}

inline int min(int a, int b) {
	return a < b ? a : b;
}