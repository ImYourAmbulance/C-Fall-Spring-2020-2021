﻿#include <iostream>
#include <cmath>
#include "Functions.h"
using namespace std;


int main() {
	// Part 1
	int n;
	cin >> n;
	int digits_sum = 0, number_of_digits = 0;
	ExploreNumber(n, digits_sum, number_of_digits);
	ChangeTheNumber(n);
	// Part 2
	int n, k;
	cin >> n >> k;
	cout << Degree(n, k) << endl;
	cout << Check(n, k) << endl;
	// Part 3
	cout << max(1, 2) << endl;
	cout << min(1, 2) << endl;
	cout << max(1, max(4, 5)) << endl;
	cout << min(1, min(0, -4)) << endl;
	int a, b;
	cin >> a >> b;
	Regulation(a, b);
	cout << a << " " << b << endl;
	cout << "My function " << CalculateSin(1) << endl;
	cout << "The function from cmath " << sin(1) << endl;
	
}

