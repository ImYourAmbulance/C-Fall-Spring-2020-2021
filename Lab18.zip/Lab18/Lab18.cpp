#include "Header.h"

int main()
{
	/*
	string filename = "test1";
	insertStaffDataInTxt(filename);
	// you should enter only one word fullname 
	readStaffDataFromTxt(filename);
	string filename = "test2";
	insertStaffDataInDat(filename);
	// you should enter only one word fullname. If fullname had type string then everything would be ok
	readStaffDataFromDat(filename);
	
	//entering and reading a sequance of doubles
	string filename = "test1";
	insertDoublestoDat(filename);
	readDoublesfromDat(filename);
	*/
	return 0;
}

