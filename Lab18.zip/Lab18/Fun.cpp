#include "Header.h"



void insertStaffDataInTxt(string& filename) {
	cout << "Enter number of staff you'd like to add in your file" << endl;
	int n;
	cin >> n;
	person* staff_to_add = new person[n];
	date birthday;
	int year, month, day;
	char fullname[128];
	char gender;
	person current_person;
	ofstream file(filename + ".txt");
	file << n << endl;
	for (int i = 0; i < n; ++i) {
		cout << "Enter the information about worker number " << i + 1 << endl;
		cout << "Year, month, day of birth - ";
		cin >> birthday.year >> birthday.month >> birthday.day;
		cout << endl << "Gender (one letter) - ";
		cin >> current_person.gender;
		cout << endl << "Full name - ";
		cin >> current_person.fullname;
		cout << endl;
		current_person.birthday = birthday;
		staff_to_add[i] = current_person;
		// well, we have inserted a staff member in the array, now it's time to put it in a file
		file << staff_to_add[i].fullname << " | " << staff_to_add[i].birthday.day << "."
			<< staff_to_add[i].birthday.month << "." << staff_to_add[i].birthday.year << " | "
			<< staff_to_add[i].gender << endl;
	}
	file.close(); 
	delete[] staff_to_add;
}

void readStaffDataFromTxt(string& filename) {
	ifstream file(filename + ".txt");
	int n;
	file >> n;
	date birthday;
	int year, month, day;
	char fullname[128];
	char gender;
	person current_person;
	for (int i = 0; i < n; ++i) {
		file >> current_person.fullname; file.ignore(3);
		cout << current_person.fullname << endl;
		file >> current_person.birthday.day; file.ignore(1);
		cout << current_person.birthday.day << ".";
		file >> current_person.birthday.month; file.ignore(1); 
		cout << current_person.birthday.month << ".";
		file >> current_person.birthday.year; file.ignore(3);
		cout << current_person.birthday.year << endl;
		file >> current_person.gender;
		cout << current_person.gender << endl;
		cout << endl;
	}
	file.close();
}

void insertStaffDataInDat(string& filename) {
	cout << "Enter number of staff you'd like to add in your file" << endl;
	int n;
	cin >> n;
	person* staff_to_add = new person[n];
	date birthday;
	int year, month, day;
	char fullname[128];
	char gender;
	person current_person;
	ofstream file(filename + ".dat", ios::binary);
	file.write(reinterpret_cast<char*>(&n), sizeof(int));
	for (int i = 0; i < n; ++i) {
		cout << "Enter the information about worker number " << i << endl;
		cout << "Year, month, day of birth - ";
		cin >> birthday.year >> birthday.month >> birthday.day;
		cout << endl << "Gender (one letter) - ";
		cin >> current_person.gender;
		cout << endl << "Full name - ";
		cin >> current_person.fullname;
		cout << endl;
		current_person.birthday = birthday;
		staff_to_add[i] = current_person;
		// well, we have inserted a staff member in the array, now it's time to put it in a file
		file.write(reinterpret_cast<char*>(&staff_to_add[i]), sizeof(person));
	}
	file.close();
}

void readStaffDataFromDat(string& filename) {
	ifstream file(filename + ".dat", ios::binary);
	int n;
	file.read(reinterpret_cast<char*>(&n), sizeof(int));
	person current_person;
	for (int i = 0; i < n; ++i) {
		file.read(reinterpret_cast<char*>(&current_person), sizeof(person));
		cout << current_person.fullname << endl;
		cout << current_person.birthday.day << "." << current_person.birthday.month << "." << current_person.birthday.year << endl;
		cout << current_person.gender << endl;
	}
	file.close();
}

void insertDoublestoDat(string& filename) {
	ofstream file(filename + ".dat", ios::binary);
	double num;
	int n; cout << "How many double will you enter?" << endl;
	cin >> n;
	int i = 0;
	while (i < n) {
		cin >> num;
		file.write(reinterpret_cast<char*>(&num), sizeof(double));
		++i;
	}
	file.close();
}

void readDoublesfromDat(string& filename) {
	ifstream file(filename + ".dat", ios::binary);
	double num;
	while (file.read(reinterpret_cast<char*>(&num), sizeof(double))) cout << num << endl;
	file.close();
}

void changeFirstAndLast(string& filename) {
	fstream file(filename + ".dat", ios::out | ios::in | ios::binary);
	double first, last;
	streampos first_pos, last_pos;
	// taking position and value of the last and the first elements
	file.seekg(0, ios::beg);
	first_pos = file.tellg();
	file.read(reinterpret_cast<char*>(&first), sizeof(first));
	int size = sizeof(last);
	file.seekg(-size, ios::end);
	last_pos = file.tellg();
	file.read(reinterpret_cast<char*>(&last), sizeof(last));

	// swaping values
	swap(first, last);

	file.seekg(first_pos, ios::beg);
	file.write(reinterpret_cast<char*>(&first), sizeof(first));

	file.seekg(last_pos, ios::beg);
	file.write(reinterpret_cast<char*>(&last), sizeof(last));

	file.close();
}