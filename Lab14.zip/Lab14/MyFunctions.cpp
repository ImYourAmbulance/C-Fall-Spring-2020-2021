#include "Header.h"

int wordCount(const string& str) {
	string s = str;
	// checking 
	if (str == "") return 0;
	// deleting spaces at the begining
	while (s[0] == ' ') s = s.substr(1, s.size());
	// deleting spaces at the end
	while (s[s.size() - 1] == ' ') s = s.substr(0, s.size() - 1);
	// deleting additional spaces
	int i = 1;
	while (i < s.size()) {
		if (s[i] == ' ' && s[i - 1] == ' ') {
			s = s.substr(0, i) + s.substr(i + 1, s.size());
			--i;
		}
		++i;
	}
	// counting spaces
	i = 0;
	int spaces = 0;
	while (i++ < s.size()) if (s[i] == ' ')  ++spaces;
	int words = spaces + 1;
	return words;
}

void deleteSymbol(string& s, char symbol) {
	string res;
	for (int i = 0; i < s.size(); ++i) res = (s[i] != symbol) ? res + s[i] : res;
	s = res;
}

void insertSubstAfterSymbol(string& s, string& subst, char symbol) {
	for (int i = 0; i < s.size(); ++i) {
		if (s[i] == symbol) {
			s = s.substr(0, i + 1) + subst + s.substr(i + 1, s.size());
		}
	}
}

void replaceEvenWordsWithWord(string& s, const string& word) {
	int word_number = 1;
	int i = 0;
	int start_pos = 0, end_pos = 0;
	while (i < s.size()) {
		if (s[i] != ' ') {
			start_pos = i;
			while (s[i] != ' ' && (i) < s.size()) ++i;
			end_pos = i;
			if ((word_number++) % 2 == 0) {
				s = s.substr(0, start_pos) + word + s.substr(end_pos, s.size());
				i = i + (word.size() - (end_pos - start_pos));
			}
		}
		++i;
	}

}
