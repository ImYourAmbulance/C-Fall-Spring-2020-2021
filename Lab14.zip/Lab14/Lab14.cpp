#include "Header.h"


int main()
{
	string s(" a  b c d e f  g ");
	string word("X");
	replaceEvenWordsWithWord(s, word);
	string result(" a  X c X e X  g ");
	cout << s;
	return 0;
}


