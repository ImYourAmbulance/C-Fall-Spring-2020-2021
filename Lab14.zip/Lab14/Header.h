#pragma once
#include <iostream>
#include <string>

using namespace std;

int wordCount(const string& s);

void deleteSymbol(string& s, char symbol);

void insertSubstAfterSymbol(string& s, string& subst, char symbol);

void replaceEvenWordsWithWord(string& s, const string& word);
