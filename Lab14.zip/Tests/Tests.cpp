#include "pch.h"
#include "CppUnitTest.h"
#include "..\Lab14\Header.h"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Tests
{
	TEST_CLASS(Task1)
	{
	public:
		TEST_METHOD(Test1)
		{
			string s(" a");
			Assert::AreEqual(wordCount(s), 1);
		}
		TEST_METHOD(Test2)
		{
			string s("  a b c   d  e  ");
			Assert::AreEqual(wordCount(s), 5);
		}
		TEST_METHOD(Test3)
		{
			string s("");
			Assert::AreEqual(wordCount(s), 0);
		}
	};
	TEST_CLASS(Task2)
	{
	public:
		TEST_METHOD(Test1)
		{
			string s("  ");
			deleteSymbol(s, ' ');
			string result("");
			Assert::AreEqual(s, result);
		}
		TEST_METHOD(Test2)
		{
			string s("abcderf");
			deleteSymbol(s, 'a');
			string result("bcderf");
			Assert::AreEqual(s,result);
		}
		TEST_METHOD(Test3)
		{
			string s("aaaaaa");
			deleteSymbol(s, 'a');
			string result("");
			Assert::AreEqual(s, result);
		}
	};
	TEST_CLASS(Task3)
	{
	public:
		TEST_METHOD(Test1)
		{
			string s("abcdefg");
			string subst("123");
			insertSubstAfterSymbol(s,subst, 'c');
		}
		TEST_METHOD(Test2)
		{
			string s("abcdefg");
			string subst("");
			insertSubstAfterSymbol(s, subst, 'g');
		}
		TEST_METHOD(Test3)
		{
			string s("abcdefg");
			string subst("123");
			insertSubstAfterSymbol(s, subst, 'a');
		}
	};
	TEST_CLASS(Task4)
	{
	public:
		TEST_METHOD(Test1)
		{
			string s("a b c d e f g");
			string word("X");
			replaceEvenWordsWithWord(s, word);
			string result("a X c X e X g");
			Assert::AreEqual(s, result);
		}
		TEST_METHOD(Test2)
		{
			string s(" a  b c d e f  g ");
			string word("X");
			replaceEvenWordsWithWord(s, word);
			string result(" a  X c X e X  g ");
			Assert::AreEqual(s, result);
		}
		TEST_METHOD(Test3)
		{
			string s("a b c");
			string word("X");
			replaceEvenWordsWithWord(s, word);
			string result("a X c");
			Assert::AreEqual(s, result);
		}
	};

}
